<?php

include "connection.php";

if(isset($_GET['id'])){
$sql = "delete from registration where id = '".$_GET['id']."'";
$result = mysql_query($sql)
}

$sql="select * from registration";
$result = mysql_query($sql);
?>