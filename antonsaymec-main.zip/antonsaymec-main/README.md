muie unguri 
@echoCum poola mea copiem site-u
Idk men
