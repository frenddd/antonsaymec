<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <title>Un1Class</title>
        <link rel="" href="">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lobster+Two&family=M+PLUS+Rounded+1c&family=Roboto+Serif:opsz@8..144&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css\index.css">
         <link rel="stylesheet" href="css\header.css">
        <link rel="stylesheet" href="css\styles\orar.css">
    </head> 
    <body class="body">
        
        <div class="header">
            <div class="parte-stanga">
           
             </div>
                 
 </div>
 
 <div class="sidenav">
    <a href="index.html"> 
        <img  class="logo" src="imagini\logo.png" width="130px"></a>
    <div class="">  
    </div>
   <div class="links">
    <!--<a class="okhome">Home</a>-->
    
    <a href="coligei.html">Colleagues</a>
    <a href="Catalogue.html">Catalogue</a>
        </div>
  </div>
  <div class="header">
    <div class="partedreapta">
<div > <a href="login.html"> <button class="signinbut">Sign in</button></a></div>
    </div>
  </div>

  <div class="box">
    <div id="slide" class="parte">
        <div class="fundal"> 
      <div class="cutie">
        <div>
          <span class="text">9th grade</span>
      
      
    </div>
      <div class="imgprof"> ]<img src="imagini/unknown.png" alt="" width="50px">
      </div>
    </div> 
     <div class="infoclas">
      <a href="video2.html"><button value="joinclass" class="joinclass">Join classroom</button></a>
      </div>
    </div>
    
  </div>
  <div id="slide2" class="parte">
    <div class="fundal"> 
  <div class="cutie">
    <div>
      <span class="text">10th grade</span>
  
  
</div>
  <div class="imgprof"> <img src="imagini/unknown.png" alt="" width="50px">
  </div>
</div> 
 <div class="infoclas">
  <a href="video2.html"><button value="joinclass" class="joinclass">Join classroom</button></a>
  </div>
</div>
  </div>
  <div id="slide3" class="parte">
    <div class="fundal"> 
  <div class="cutie">
    <div>
      <span class="text">11th grade</span>
  
  
</div>
  <div class="imgprof">  <img src="imagini/unknown.png" alt="" width="50px">
  </div>
</div> 
 <div class="infoclas">
  <a href="video2.html"><button value="joinclass" class="joinclass">Join classroom</button></a>
  </div>
</div>
</div>
<div id="slide4" class="parte">
  <div class="fundal"> 
<div class="cutie">
  <div>
    <span class="text">12th grade</span>


</div>
<div class="imgprof">  <img src="imagini/unknown.png" alt="" width="50px">
</div>
</div> 
<div class="infoclas">
  <a href="video2.html"><button value="joinclass" class="joinclass">Join classroom</button></a>
</div>
</div>



    </body>
</html>